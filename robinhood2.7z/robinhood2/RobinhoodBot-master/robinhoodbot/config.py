#Enter your robinhood username and password here, then save this file in the same directory as a regular python file
rh_password="pin576nine242!"
rh_username="simotsu@gmail.com"
# change to false to run frfr
debug=True
# set to show plot; if set to false plot will not show
plot=True
